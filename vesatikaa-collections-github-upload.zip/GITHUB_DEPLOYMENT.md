# VESatikaa Collections — GitHub upload and live deployment

## Important: GitHub Pages is not enough for this project

VESatikaa Collections is a full-stack React + Express + tRPC application. It requires a Node.js server, MySQL/TiDB database, OAuth configuration, and storage/API credentials. GitHub Pages serves static files only, so it cannot run the admin panel, database-backed products, authentication, or WhatsApp settings.

Use GitHub as the source repository, then deploy the app to a Node-compatible host such as Render, Railway, Fly.io, or a VPS.

## Upload to GitHub

1. Create a new GitHub repository.
2. Upload the contents of this package, excluding `node_modules`, `dist`, `.git`, and `.manus-logs`.
3. Keep `package.json` and `pnpm-lock.yaml` in the repository root.
4. Add the required environment variables listed below as encrypted environment variables in the hosting provider. Never commit real secret values.
5. The included `.github/workflows/ci.yml` will run tests, TypeScript checks, and a production build on pushes and pull requests to `main`.

## Node host settings

- **Install command:** `pnpm install --frozen-lockfile`
- **Build command:** `pnpm build`
- **Start command:** `pnpm start`
- **Node version:** 20 or newer
- **Port:** use the host-provided `PORT` value; the server already reads the runtime environment used by the project template

## Required secrets

Add these names to the host's secret manager:

```text
DATABASE_URL
JWT_SECRET
VITE_APP_ID
OAUTH_SERVER_URL
OWNER_OPEN_ID
BUILT_IN_FORGE_API_URL
BUILT_IN_FORGE_API_KEY
NODE_ENV=production
```

The database must be reachable by the deployed server, and the OAuth callback must be configured for the deployed domain. Do not put database URLs, JWT secrets, OAuth secrets, or API keys in GitHub source files.

## Database

The schema and migrations are in `drizzle/`. After configuring `DATABASE_URL`, run the project's migration workflow from a trusted deployment environment before using the admin panel. Back up the database before applying migrations.

## GitHub Pages option

GitHub Pages can host only a separate static marketing export. It will not provide the current live functionality, including products from the database, admin login, stock management, or WhatsApp settings. For the current website, use the Node deployment instructions above.
