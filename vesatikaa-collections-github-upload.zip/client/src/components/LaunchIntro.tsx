import { useCallback, useEffect, useRef, useState } from "react";

const launchVideo = "/manus-storage/vesatikaa-user-intro-3s-to-9s_20b1fe25.mp4";

export default function LaunchIntro({ onComplete }: { onComplete: () => void }) {
  const [reducedMotion, setReducedMotion] = useState(false);
  const [exiting, setExiting] = useState(false);
  const [soundOn, setSoundOn] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  const finish = useCallback(() => {
    if (exiting) return;
    setExiting(true);
    window.setTimeout(onComplete, 520);
  }, [exiting, onComplete]);

  useEffect(() => {
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReducedMotion(media.matches);
    update();
    media.addEventListener("change", update);
    return () => media.removeEventListener("change", update);
  }, []);

  useEffect(() => {
    if (reducedMotion) onComplete();
  }, [reducedMotion, onComplete]);

  if (reducedMotion) return null;

  return (
    <div className={`fixed inset-0 z-[100] overflow-hidden bg-[#6f1d35] transition-opacity duration-500 ease-out ${exiting ? "pointer-events-none opacity-0" : "opacity-100"}`} role="dialog" aria-label="VESatikaa launch intro">
      <video
        ref={videoRef}
        className="h-full w-full object-cover"
        autoPlay
        muted
        playsInline
        onEnded={finish}
        onError={finish}
      >
        <source src={launchVideo} type="video/mp4" />
      </video>
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#2f1420]/55 via-transparent to-[#2f1420]/15" />
      <div className="absolute inset-x-0 top-0 flex items-center justify-between px-5 py-5 sm:px-8 sm:py-7">
        <div className="text-[#fff8f0]">
          <p className="text-[0.65rem] font-bold uppercase tracking-[0.28em]">VESATIKAA</p>
          <p className="mt-1 text-[0.55rem] uppercase tracking-[0.3em] text-[#e8c988]">Collections</p>
        </div>
        <div className="pointer-events-auto flex items-center gap-2">
          <button onClick={() => { if (videoRef.current) { videoRef.current.muted = false; void videoRef.current.play(); } setSoundOn(true); }} className={`rounded-full border border-white/50 bg-[#2f1420]/25 px-4 py-2 text-[0.62rem] font-bold uppercase tracking-[0.15em] text-white backdrop-blur-sm transition-colors hover:bg-white hover:text-[#6f1d35] ${soundOn ? "hidden" : "inline-flex"}`} aria-label="Enable launch music">Sound on</button>
          <button onClick={finish} className="rounded-full border border-white/50 bg-[#2f1420]/25 px-4 py-2 text-[0.62rem] font-bold uppercase tracking-[0.15em] text-white backdrop-blur-sm transition-colors hover:bg-white hover:text-[#6f1d35]" aria-label="Skip VESatikaa intro">Skip intro</button>
        </div>
      </div>
      <div className="pointer-events-none absolute inset-x-0 bottom-8 text-center text-[0.6rem] font-bold uppercase tracking-[0.28em] text-white/75 sm:bottom-10">
        A wardrobe, made personal
      </div>
    </div>
  );
}
