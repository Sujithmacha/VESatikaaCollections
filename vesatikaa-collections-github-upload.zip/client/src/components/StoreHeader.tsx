import { Instagram, Menu, MessageCircle, X } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";
import { whatsappLink } from "@/lib/brand";
import { AUTHORIZED_ADMIN_EMAIL } from "@shared/const";
import { trpc } from "@/lib/trpc";

type StoreHeaderProps = { whatsappNumber?: string };

export default function StoreHeader({ whatsappNumber }: StoreHeaderProps) {
  const [open, setOpen] = useState(false);
  const { data: user } = trpc.auth.me.useQuery();
  const canSeeOwnerLogin = user?.email?.trim().toLowerCase() === AUTHORIZED_ADMIN_EMAIL;
  const nav = [
    { label: "Collections", href: "/#collections" },
    { label: "Custom orders", href: "/#custom-orders" },
    { label: "Our story", href: "/#about" },
    ...(canSeeOwnerLogin ? [{ label: "Owner login", href: "/admin" }] : []),
  ];

  return (
    <header className="sticky top-0 z-50 border-b border-[#eaded5]/80 bg-[#fbf7f2]/90 backdrop-blur-xl">
      <div className="container flex h-[72px] items-center justify-between gap-4">
        <Link href="/" className="group flex items-center gap-3" onClick={() => setOpen(false)}>
          <span className="flex h-10 w-10 items-center justify-center rounded-full border border-[#d0a85c] text-[#6f1d35] transition-transform group-hover:rotate-6">
            <span className="serif-display text-lg italic">V</span>
          </span>
          <span className="leading-none">
            <span className="block font-semibold tracking-[0.22em] text-[#6f1d35] text-[0.72rem]">VESATIKAA</span>
            <span className="mt-1 block text-[0.58rem] uppercase tracking-[0.28em] text-[#a17745]">Collections</span>
          </span>
        </Link>

        <nav className="hidden items-center gap-8 text-[0.72rem] font-semibold uppercase tracking-[0.16em] text-[#756a63] md:flex">
          {nav.map((item) => <a key={item.href} className={`editorial-link inline-block transition-all duration-200 hover:-translate-y-0.5 hover:text-[#6f1d35] ${item.label === "Custom orders" ? "hover:drop-shadow-[0_4px_8px_rgba(111,29,53,.18)]" : ""}`} href={item.href}>{item.label}</a>)}
        </nav>

        <div className="flex items-center gap-2">
          <a className="hidden rounded-full border border-[#d0a85c]/70 px-4 py-2 text-[0.69rem] font-bold uppercase tracking-[0.12em] text-[#6f1d35] transition-all duration-200 hover:-translate-y-0.5 hover:bg-[#f3e6e1] hover:shadow-[0_8px_20px_rgba(111,29,53,.14)] active:scale-95 sm:inline-flex" href={whatsappLink(whatsappNumber, "Hi VESatikaa! I have a doubt about the website and ordering process. Could you please help me?")} target="_blank" rel="noreferrer">
            <MessageCircle className="mr-2 h-3.5 w-3.5" /> Enquire
          </a>
          <button className="flex h-10 w-10 items-center justify-center rounded-full border border-[#eaded5] text-[#6f1d35] md:hidden" aria-label={open ? "Close navigation" : "Open navigation"} onClick={() => setOpen((value) => !value)}>
            {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </button>
        </div>
      </div>
      {open && (
        <div className="border-t border-[#eaded5] bg-[#fffdf9] px-4 py-5 md:hidden">
          <nav className="container flex flex-col gap-4 text-sm font-semibold uppercase tracking-[0.16em] text-[#6f1d35]">
            {nav.map((item) => <a key={item.href} href={item.href} onClick={() => setOpen(false)}>{item.label}</a>)}
            <a href="https://instagram.com/vesatikaa_collections_2024" target="_blank" rel="noreferrer" className="flex items-center gap-2 text-[#a17745]"><Instagram className="h-4 w-4" /> Instagram</a>
          </nav>
        </div>
      )}
    </header>
  );
}
