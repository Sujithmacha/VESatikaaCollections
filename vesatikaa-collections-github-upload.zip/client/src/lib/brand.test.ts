import { describe, expect, it } from "vitest";
import { formatInr, whatsappLink } from "./brand";

describe("brand helpers", () => {
  it("normalizes the configurable WhatsApp number and encodes the message", () => {
    expect(whatsappLink("+91 8328536597", "Hi VESatikaa! I'd like to enquire about Maroon Silk Drape.")).toBe("https://api.whatsapp.com/send?phone=918328536597&text=Hi%20VESatikaa!%20I'd%20like%20to%20enquire%20about%20Maroon%20Silk%20Drape.");
  });

  it("uses the configured fallback WhatsApp number when settings are unavailable", () => {
    expect(whatsappLink(undefined, "Hello")).toBe("https://api.whatsapp.com/send?phone=918328536597&text=Hello");
  });

  it("formats prices in the Indian locale", () => {
    expect(formatInr(18900)).toBe("₹18,900");
  });
});
