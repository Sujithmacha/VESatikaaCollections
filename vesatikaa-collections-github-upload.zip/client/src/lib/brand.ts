export const fallbackSettings = {
  whatsappNumber: "+91 8328536597",
  instagramHandle: "@vesatikaa_collections_2024",
  founderName: "Samatha Mallekedi",
  founderBio: "VESatikaa Collections is a space for women who want their ethnic wear to feel personal. Samatha works with each customer to shape the silhouette, colour story and finishing details around the moment they are dressing for.",
  founderImageUrl: null,
};

export function whatsappLink(number: string | undefined, message: string) {
  const normalized = (number || fallbackSettings.whatsappNumber).replace(/\D/g, "");
  return `https://api.whatsapp.com/send?phone=${normalized}&text=${encodeURIComponent(message)}`;
}

export function formatInr(value: number) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(value);
}
