import { describe, expect, it } from "vitest";
import { isResizeObserverLoopError } from "./resizeObserver";

describe("ResizeObserver error filter", () => {
  it("recognizes the browser's completed-notifications warning", () => {
    expect(isResizeObserverLoopError("ResizeObserver loop completed with undelivered notifications.")).toBe(true);
  });

  it("recognizes the browser's loop-limit warning", () => {
    expect(isResizeObserverLoopError("ResizeObserver loop limit exceeded")).toBe(true);
  });

  it("does not hide unrelated errors", () => {
    expect(isResizeObserverLoopError("TypeError: Cannot read properties of undefined")).toBe(false);
    expect(isResizeObserverLoopError("ResizeObserver loop completed with undelivered notifications. extra")).toBe(false);
  });
});
