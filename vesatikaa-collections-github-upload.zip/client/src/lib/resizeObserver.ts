const resizeObserverLoopMessage = /^ResizeObserver loop (completed with undelivered notifications|limit exceeded)\.?$/;

export function isResizeObserverLoopError(message: string) {
  return resizeObserverLoopMessage.test(message);
}
