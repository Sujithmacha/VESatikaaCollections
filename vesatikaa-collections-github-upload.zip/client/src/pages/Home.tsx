import { motion } from "framer-motion";
import { ArrowDownRight, ArrowUpRight, Check, ChevronRight, Instagram, MessageCircle, Sparkles } from "lucide-react";
import { useMemo, useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import StoreHeader from "@/components/StoreHeader";
import { fallbackSettings, formatInr, whatsappLink } from "@/lib/brand";

const editorialImages = [
  { src: "/manus-storage/editorial-saree_2a91400a.jpg", alt: "Editorial Indian saree styling in deep maroon", tall: true, label: "The drape" },
  { src: "/manus-storage/fabric_febf102e.jpg", alt: "Colourful handloom textile detail", tall: false, label: "Colour stories" },
  { src: "/manus-storage/editorial-white_bdfb9cd6.jpg", alt: "White Indian fashion editorial", tall: true, label: "Quiet luxury" },
  { src: "/manus-storage/editorial-fashion_8c093a38.jpg", alt: "Indian fashion portrait", tall: false, label: "Made personal" },
  { src: "/manus-storage/editorial-bridal_bafc2d75.jpg", alt: "Indian bridal fashion editorial", tall: true, label: "For your moment" },
];

const categoryTabs = ["All", "Kids Wear", "Sarees", "Couple Wear"] as const;

function SectionIntro({ eyebrow, title, copy, light = false }: { eyebrow: string; title: string; copy?: string; light?: boolean }) {
  return (
    <div className={light ? "text-[#fff8f0]" : "text-[#29231f]"}>
      <p className={light ? "eyebrow text-[#e8c988]" : "eyebrow"}>{eyebrow}</p>
      <h2 className="mt-4 max-w-2xl text-4xl leading-[1.05] tracking-[-0.03em] sm:text-5xl">{title}</h2>
      {copy && <p className={light ? "mt-5 max-w-xl text-sm leading-7 text-[#f5dfd6]/80 sm:text-base" : "mt-5 max-w-xl text-sm leading-7 text-[#756a63] sm:text-base"}>{copy}</p>}
    </div>
  );
}

function ProductCard({ product, whatsappNumber }: { product: any; whatsappNumber?: string }) {
  const image = product.images?.[0] || editorialImages[0].src;
  const orderMessage = `Hi VESatikaa! I'd like to order ${product.name} for ${formatInr(product.price)}. Please confirm size, availability and delivery details.`;
  return (
    <motion.article initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} className="group min-w-[275px] snap-start sm:min-w-0">
      <Link href={`/product/${product.slug}`} className="block">
        <div className="image-reveal relative aspect-[1.08] overflow-hidden rounded-[1.35rem] bg-[#eaded5] sm:aspect-[4/5]">
          <img src={image} alt={product.name} loading="lazy" className="h-full w-full object-contain sm:object-cover" />
          <div className="absolute left-4 top-4 flex gap-2">
            {product.newArrival && <span className="rounded-full bg-[#fffdf9]/90 px-3 py-1 text-[0.62rem] font-bold uppercase tracking-[0.14em] text-[#6f1d35]">New</span>}
            {product.featured && <span className="rounded-full bg-[#6f1d35]/90 px-3 py-1 text-[0.62rem] font-bold uppercase tracking-[0.14em] text-white">Featured</span>}
            <span className={`rounded-full px-3 py-1 text-[0.62rem] font-bold uppercase tracking-[0.14em] ${product.availableStock > 0 ? "bg-[#e5f0e7]/95 text-[#2f6b43]" : "bg-[#f1ebe5]/95 text-[#756a63]"}`}>{product.availableStock > 0 ? "In stock" : "Out of stock"}</span>
          </div>
          <div className="absolute bottom-4 right-4 flex h-10 w-10 translate-y-2 items-center justify-center rounded-full bg-[#fffdf9]/90 text-[#6f1d35] opacity-0 transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100"><ArrowUpRight className="h-4 w-4" /></div>
        </div>
        <div className="pt-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-[0.65rem] font-bold uppercase tracking-[0.14em] text-[#a17745]">{product.category}</p>
              <h3 className="mt-1 text-xl tracking-[-0.02em] text-[#29231f]">{product.name}</h3>
            </div>
            <p className="pt-1 text-sm font-semibold text-[#6f1d35]">{formatInr(product.price)}</p>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-[#eaded5] bg-[#eaded5] text-[0.62rem] sm:text-[0.68rem]">
            <div className="bg-[#fbf7f2] px-2.5 py-2 sm:px-3 sm:py-2.5"><span className="block text-[0.54rem] font-bold uppercase tracking-[0.07em] text-[#a17745] sm:text-[0.62rem] sm:tracking-[0.1em]">Size</span><span className="mt-1 block line-clamp-2 leading-4 text-[#756a63]">{product.size}</span></div>
            <div className="bg-[#fbf7f2] px-2.5 py-2 sm:px-3 sm:py-2.5"><span className="block text-[0.54rem] font-bold uppercase tracking-[0.07em] text-[#a17745] sm:text-[0.62rem] sm:tracking-[0.1em]">Fabric type</span><span className="mt-1 block line-clamp-2 leading-4 text-[#756a63]">{product.clothQuality}</span></div>
            <div className="bg-[#fbf7f2] px-2.5 py-2 sm:px-3 sm:py-2.5"><span className="block text-[0.54rem] font-bold uppercase tracking-[0.07em] text-[#a17745] sm:text-[0.62rem] sm:tracking-[0.1em]">Price</span><span className="mt-1 block font-semibold leading-4 text-[#6f1d35]">{formatInr(product.price)}</span></div>
          </div>
        </div>
      </Link>
      <a href={whatsappLink(whatsappNumber, orderMessage)} target="_blank" rel="noreferrer" className="mt-4 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.14em] text-[#6f1d35] transition-colors hover:text-[#a17745]">
        <MessageCircle className="h-3.5 w-3.5" /> {product.availableStock > 0 ? "Order on WhatsApp" : "Ask about availability"} <ChevronRight className="h-3.5 w-3.5" />
      </a>
    </motion.article>
  );
}

export default function Home() {
  const settingsQuery = trpc.settings.get.useQuery();
  const productsQuery = trpc.products.list.useQuery({});
  const galleryQuery = trpc.gallery.list.useQuery();
  const [category, setCategory] = useState<(typeof categoryTabs)[number]>("All");
  const settings = settingsQuery.data ?? fallbackSettings;
  const products = productsQuery.data ?? [];
  const gallery = galleryQuery.data ?? [];
  const filteredProducts = useMemo(() => category === "All" ? products : products.filter((product) => product.category === category), [category, products]);
  const galleryImages = gallery.length ? gallery.map((item) => ({ src: item.imageUrl, alt: item.altText, caption: item.caption })) : editorialImages.map((item) => ({ src: item.src, alt: item.alt, caption: item.label }));
  const followGalleryImages = [
    { src: "/manus-storage/vesatikaa-follow-feedback_ee6f8a58.png", alt: "Customer feedback shared with VESatikaa Collections" },
    { src: "/manus-storage/vesatikaa-follow-saree-feedback_c47d4afc.png", alt: "Customer feedback about a VESatikaa saree" },
    { src: "/manus-storage/vesatikaa-follow-yellow-feedback_2ca03dc8.png", alt: "Customer feedback about a VESatikaa yellow outfit" },
    ...galleryImages.slice(3, 4),
  ];
  const customOrderLink = whatsappLink(settings.whatsappNumber, "Hi VESatikaa! I'd like to discuss a custom order.");

  return (
    <div className="min-h-screen overflow-hidden bg-[#fbf7f2]">
      <StoreHeader whatsappNumber={settings.whatsappNumber} />
      <main>
        <section className="container relative grid min-h-[calc(100vh-72px)] items-center gap-12 py-16 lg:grid-cols-[1.03fr_.97fr] lg:gap-20 lg:py-20">
          <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .6 }} className="relative z-10">
            <div className="mb-7 flex items-center gap-3"><span className="h-px w-12 bg-[#d0a85c]" /><p className="eyebrow">A wardrobe, made personal</p></div>
            <h1 className="max-w-[720px] text-[3.7rem] leading-[.98] tracking-[-0.055em] text-[#6f1d35] sm:text-[5.2rem] lg:text-[6.2rem]">Customised sarees <span className="text-[#a17745]">&amp;</span> dresses,<br /><em className="font-normal text-[#29231f]">made just for you.</em></h1>
            <p className="mt-7 max-w-xl text-base leading-8 text-[#756a63] sm:text-lg">Ethnic pieces shaped around your style, your colours and the occasion you are dressing for. Start with a feeling — we will take it from there.</p>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row">
              <a href="#collections" className="luxury-button inline-flex items-center justify-center gap-3 rounded-full bg-[#6f1d35] px-6 py-3.5 text-xs font-bold uppercase tracking-[0.16em] text-white hover:bg-[#54202f]">Explore collections <ArrowDownRight className="h-4 w-4" /></a>
              <a href={customOrderLink} target="_blank" rel="noreferrer" className="luxury-button inline-flex items-center justify-center gap-3 rounded-full border border-[#d0a85c] px-6 py-3.5 text-xs font-bold uppercase tracking-[0.16em] text-[#6f1d35] hover:bg-[#f3e6e1]"><MessageCircle className="h-4 w-4" /> Order on WhatsApp</a>
            </div>
            <div className="mt-12 flex items-center gap-7 border-t border-[#eaded5] pt-6 text-xs text-[#756a63]">
              <span><strong className="block text-xl font-normal text-[#6f1d35]">01</strong> Tell us your moment</span><span className="h-8 w-px bg-[#eaded5]" /><span><strong className="block text-xl font-normal text-[#6f1d35]">02</strong> We shape the details</span>
            </div>
          </motion.div>
          <motion.div initial={{ opacity: 0, scale: .97 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: .8, delay: .12 }} className="relative mx-auto w-full max-w-[520px] lg:mr-0">
            <div className="relative aspect-square overflow-hidden rounded-full bg-[#eee8ef] p-3 shadow-[0_30px_80px_rgba(74,50,38,.16)]">
              <img src="/manus-storage/vesatikaa-brand-portrait_a35f9b17.png" alt="VESatikaa Collections saree portrait" className="h-full w-full scale-[1.06] rounded-full object-cover" />
              <div className="absolute bottom-7 left-7 right-7 flex items-end justify-between rounded-2xl bg-[#fffdf9]/90 p-4 backdrop-blur-md"><div><p className="eyebrow">VESatikaa Collections</p><p className="mt-1 serif-display text-xl italic text-[#6f1d35]">Custom pieces shaped around your moment.</p></div><Sparkles className="mb-1 h-5 w-5 shrink-0 text-[#d0a85c]" /></div>
            </div>
          </motion.div>
        </section>

        <section className="border-y border-[#eaded5] bg-[#f4ede7] py-8"><div className="container flex flex-wrap items-center justify-center gap-x-8 gap-y-3 text-center text-[0.66rem] font-bold uppercase tracking-[0.2em] text-[#8e766b] sm:justify-between"><span>Customised silhouettes</span><span className="hidden h-1 w-1 rounded-full bg-[#d0a85c] sm:block" /><span>Made for your moment</span><span className="hidden h-1 w-1 rounded-full bg-[#d0a85c] sm:block" /><span>Delivery across India</span><span className="hidden h-1 w-1 rounded-full bg-[#d0a85c] sm:block" /><span>Enquire directly</span></div></section>

        <section className="py-20 sm:py-28"><div className="container"><div className="flex items-end justify-between gap-6"><SectionIntro eyebrow="A little visual language" title="The edit, in motion." copy="Textures, drapes and details to start your moodboard. Save a feeling, then bring it to WhatsApp." /><span className="hidden pb-2 text-[0.68rem] font-bold uppercase tracking-[0.16em] text-[#a17745] sm:block">Swipe to discover →</span></div><div className="mobile-scrollbar mt-10 flex snap-x gap-4 overflow-x-auto pb-5 md:grid md:grid-cols-[.9fr_1.2fr_.85fr_1fr_1.1fr] md:items-end md:overflow-visible">{galleryImages.slice(0, 5).map((item, index) => <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: .2 }} transition={{ delay: index * .06 }} key={`${item.src}-${index}`} className={`group image-reveal relative min-w-[220px] snap-start overflow-hidden rounded-[1.25rem] bg-[#eaded5] ${editorialImages[index]?.tall ? "md:mb-10" : "md:mb-0"} ${index % 2 === 1 ? "aspect-[1.06]" : "aspect-[.82]"}`}><img src={item.src} alt={item.alt} loading="lazy" className="h-full w-full object-cover" /><div className="absolute inset-x-3 bottom-3 rounded-xl bg-[#29231f]/72 px-3 py-2 text-xs text-white backdrop-blur-md"><span>{item.caption || "VESatikaa edit"}</span></div></motion.div>)}</div></div></section>

        <section id="collections" className="scroll-mt-20 bg-[#fffdf9] py-20 sm:py-28"><div className="container"><div className="flex flex-col justify-between gap-8 sm:flex-row sm:items-end"><SectionIntro eyebrow="Collections" title="Pieces with a point of view." copy="Browse the current edit, then enquire directly. Every product conversation begins on WhatsApp." /><div className="flex max-w-full gap-2 overflow-x-auto pb-1">{categoryTabs.map((tab) => <button key={tab} onClick={() => setCategory(tab)} className={`whitespace-nowrap rounded-full border px-4 py-2.5 text-[0.68rem] font-bold uppercase tracking-[0.12em] transition-all ${category === tab ? "border-[#6f1d35] bg-[#6f1d35] text-white" : "border-[#eaded5] text-[#756a63] hover:border-[#d0a85c] hover:text-[#6f1d35]"}`}>{tab}</button>)}</div></div><div className="mt-12">{productsQuery.isLoading ? <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3"><div className="h-[420px] animate-pulse rounded-[1.35rem] bg-[#f1ebe5]" /><div className="hidden h-[420px] animate-pulse rounded-[1.35rem] bg-[#f1ebe5] sm:block" /><div className="hidden h-[420px] animate-pulse rounded-[1.35rem] bg-[#f1ebe5] lg:block" /></div> : filteredProducts.length ? <div className="mobile-scrollbar flex snap-x gap-7 overflow-x-auto pb-6 sm:grid sm:grid-cols-2 sm:overflow-visible lg:grid-cols-3">{filteredProducts.map((product) => <ProductCard key={product.id} product={product} whatsappNumber={settings.whatsappNumber} />)}</div> : <div className="rounded-[1.5rem] border border-dashed border-[#d0a85c] bg-[#fbf7f2] px-6 py-16 text-center"><p className="eyebrow">The edit is being curated</p><h3 className="mt-3 text-3xl text-[#6f1d35]">Your next favourite piece is on its way.</h3><p className="mx-auto mt-3 max-w-md text-sm leading-7 text-[#756a63]">In the meantime, tell us what you are looking for and we will shape a custom order around it.</p><a className="mt-6 inline-flex items-center gap-2 rounded-full bg-[#6f1d35] px-5 py-3 text-xs font-bold uppercase tracking-[0.15em] text-white" href={customOrderLink} target="_blank" rel="noreferrer"><MessageCircle className="h-4 w-4" /> Start on WhatsApp</a></div>}</div></div></section>

        <section id="custom-orders" className="scroll-mt-20 overflow-hidden bg-[#6f1d35] py-20 sm:py-28"><div className="container grid gap-14 lg:grid-cols-[.8fr_1.2fr] lg:items-center"><div><SectionIntro light eyebrow="Custom orders" title="Made for your moment." copy="Bring us the moodboard in your head. We will talk through the occasion, silhouette and details that make it feel like yours." /><a href={customOrderLink} target="_blank" rel="noreferrer" className="mt-8 inline-flex items-center gap-3 rounded-full bg-[#e8c988] px-6 py-3.5 text-xs font-bold uppercase tracking-[0.16em] text-[#4e2b27] transition-transform hover:-translate-y-0.5"><MessageCircle className="h-4 w-4" /> Start a custom order</a></div><div className="grid gap-3 sm:grid-cols-2"><div className="rounded-[1.4rem] border border-white/15 bg-[#7e2944] p-6 sm:translate-y-8"><span className="eyebrow text-[#e8c988]">Share your cues</span><ul className="mt-5 space-y-3 text-sm leading-6 text-[#fff8f0]/80">{["Occasion & mood", "Style references", "Colours & fabric", "Inspiration images", "Customisation details"].map((item) => <li key={item} className="flex items-center gap-3"><Check className="h-4 w-4 shrink-0 text-[#e8c988]" /> {item}</li>)}</ul></div><div className="rounded-[1.4rem] border border-[#e8c988]/35 bg-[#4b1829] p-6"><span className="eyebrow text-[#e8c988]">We take it from there</span><p className="mt-5 serif-display text-3xl leading-tight text-[#fff8f0]">A conversation, not a checkout.</p><p className="mt-5 text-sm leading-6 text-[#f5dfd6]/75">The details are discussed directly with Samatha so the final piece feels considered from first sketch to delivery.</p></div></div></div></section>

        <section className="py-20 sm:py-28"><div className="container"><SectionIntro eyebrow="How VESatikaa works" title="A softer way to shop occasion wear." /><div className="mt-12 grid gap-px overflow-hidden rounded-[1.5rem] border border-[#eaded5] bg-[#eaded5] sm:grid-cols-5">{[{ n: "01", title: "Explore", text: "Browse sarees, dresses and new arrivals." }, { n: "02", title: "Enquire", text: "Click WhatsApp on a product." }, { n: "03", title: "Discuss", text: "Share your style, occasion and details." }, { n: "04", title: "Confirm", text: "Final details are discussed directly." }, { n: "05", title: "Receive", text: "Your customised outfit is prepared and delivered." }].map((step, index) => <div key={step.n} className={`bg-[#fffdf9] p-6 ${index === 0 ? "sm:rounded-l-[1.4rem]" : ""} ${index === 4 ? "sm:rounded-r-[1.4rem]" : ""}`}><span className="serif-display text-3xl italic text-[#d0a85c]">{step.n}</span><h3 className="mt-7 text-2xl text-[#6f1d35]">{step.title}</h3><p className="mt-3 text-sm leading-6 text-[#756a63]">{step.text}</p></div>)}</div></div></section>

        <section id="about" className="scroll-mt-20 border-t border-[#eaded5] bg-[#f4ede7] py-20 sm:py-28"><div className="container grid gap-10 lg:grid-cols-[.85fr_1.15fr] lg:items-center"><div className="relative mx-auto aspect-[.85] w-full max-w-[400px] overflow-hidden rounded-[7rem_7rem_1.5rem_1.5rem] bg-[#4b1829] p-3">{settings.founderImageUrl ? <img src={settings.founderImageUrl} alt={settings.founderName} className="h-full w-full rounded-[6.5rem_6.5rem_1.15rem_1.15rem] object-cover" /> : <div className="flex h-full w-full items-center justify-center rounded-[6.5rem_6.5rem_1.15rem_1.15rem] border border-[#e8c988]/40 bg-[radial-gradient(circle_at_40%_28%,rgba(232,201,136,.28),transparent_25%),linear-gradient(145deg,#7e2944,#3d1726)]"><div className="text-center text-[#fff8f0]"><p className="serif-display text-8xl italic leading-none text-[#e8c988]">S</p><p className="mt-3 text-[0.65rem] font-bold uppercase tracking-[0.23em] text-[#f5dfd6]/75">A founder's note</p></div></div>}<div className="absolute bottom-7 left-7 rounded-full bg-[#fffdf9]/90 px-4 py-2 text-[0.62rem] font-bold uppercase tracking-[0.15em] text-[#6f1d35]">Meet {settings.founderName.split(" ")[0]}</div></div><div><SectionIntro eyebrow="The person behind the pieces" title={`Meet ${settings.founderName.split(" ")[0]}.`} copy={settings.founderBio} /><div className="gold-rule my-8 max-w-sm" /><p className="max-w-xl text-sm leading-7 text-[#756a63]">VESatikaa is a place for thoughtful conversations about how you want to feel in what you wear. If you have a vision, Samatha would love to hear it.</p><a href={customOrderLink} target="_blank" rel="noreferrer" className="mt-8 inline-flex items-center gap-3 text-xs font-bold uppercase tracking-[0.16em] text-[#6f1d35] editorial-link">Begin a conversation <ArrowUpRight className="h-4 w-4" /></a></div></div></section>

        <section className="py-20 sm:py-28"><div className="container"><div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><SectionIntro eyebrow="From the studio" title="Follow VESatikaa." copy="Moodboards, drapes and the little details in between." /></div><a href="https://instagram.com/vesatikaa_collections_2024" target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 text-sm font-semibold text-[#6f1d35]"> <Instagram className="h-4 w-4" /> {settings.instagramHandle}</a></div><div className="mobile-scrollbar mt-10 flex snap-x gap-4 overflow-x-auto pb-4 md:grid md:grid-cols-4 md:overflow-visible">{followGalleryImages.slice(0, 4).map((item, index) => <a key={`insta-${item.src}-${index}`} href="https://instagram.com/vesatikaa_collections_2024" target="_blank" rel="noreferrer" className="image-reveal group relative aspect-square min-w-[210px] snap-start overflow-hidden rounded-[1.25rem] bg-[#eaded5]"><img src={item.src} alt={item.alt} loading="lazy" className="h-full w-full object-cover" /><div className="absolute inset-0 flex items-center justify-center bg-[#6f1d35]/55 opacity-0 transition-opacity group-hover:opacity-100"><Instagram className="h-6 w-6 text-white" /></div></a>)}</div></div></section>
      </main>
      <footer className="border-t border-[#eaded5] bg-[#2f2422] py-10 text-[#fff8f0]"><div className="container flex flex-col gap-8 sm:flex-row sm:items-end sm:justify-between"><div><div className="flex items-center gap-3"><span className="flex h-10 w-10 items-center justify-center rounded-full border border-[#d0a85c] text-[#e8c988]"><span className="serif-display text-lg italic">V</span></span><span><span className="block text-sm font-semibold tracking-[0.22em]">VESATIKAA</span><span className="mt-1 block text-[0.58rem] uppercase tracking-[0.28em] text-[#e8c988]">Collections</span></span></div><p className="mt-5 max-w-xs text-sm leading-6 text-[#f5dfd6]/65">Customised sarees &amp; dresses, made around your moment.</p></div><div className="flex flex-col gap-3 text-sm text-[#f5dfd6]/75 sm:items-end"><a className="inline-flex items-center gap-2 hover:text-[#e8c988]" href={customOrderLink} target="_blank" rel="noreferrer"><MessageCircle className="h-4 w-4" /> WhatsApp</a><a className="inline-flex items-center gap-2 hover:text-[#e8c988]" href="https://instagram.com/vesatikaa_collections_2024" target="_blank" rel="noreferrer"><Instagram className="h-4 w-4" /> {settings.instagramHandle}</a><Link className="inline-flex items-center gap-2 text-[#e8c988] hover:text-white" href="/admin">Admin</Link></div></div><div className="container mt-10 flex flex-col gap-3 border-t border-white/10 pt-5 text-[0.65rem] uppercase tracking-[0.13em] text-[#f5dfd6]/45 sm:flex-row sm:justify-between"><span>© {new Date().getFullYear()} VESatikaa Collections</span><span>Made for the moments you keep.</span></div></footer>
    </div>
  );
}
