import { motion } from "framer-motion";
import { ArrowLeft, ChevronLeft, ChevronRight, MessageCircle } from "lucide-react";
import { useState } from "react";
import { Link, useRoute } from "wouter";
import StoreHeader from "@/components/StoreHeader";
import { fallbackSettings, formatInr, whatsappLink } from "@/lib/brand";
import { trpc } from "@/lib/trpc";

export default function ProductDetail() {
  const [, params] = useRoute("/product/:slug");
  const productQuery = trpc.products.bySlug.useQuery({ slug: params?.slug ?? "" }, { enabled: Boolean(params?.slug) });
  const settingsQuery = trpc.settings.get.useQuery();
  const settings = settingsQuery.data ?? fallbackSettings;
  const product = productQuery.data;
  const [selectedImage, setSelectedImage] = useState(0);

  if (productQuery.isLoading) return <div className="flex min-h-screen items-center justify-center bg-[#fbf7f2] text-sm text-[#756a63]">Loading the piece…</div>;
  if (productQuery.isError || !product) return <div className="min-h-screen bg-[#fbf7f2]"><StoreHeader whatsappNumber={settings.whatsappNumber} /><div className="container flex min-h-[70vh] flex-col items-center justify-center text-center"><p className="eyebrow">Piece not found</p><h1 className="mt-4 text-4xl text-[#6f1d35]">This edit has moved on.</h1><p className="mt-3 max-w-md text-sm leading-7 text-[#756a63]">Try exploring the current collection or begin a custom order with Samatha.</p><Link href="/#collections" className="mt-7 rounded-full bg-[#6f1d35] px-5 py-3 text-xs font-bold uppercase tracking-[0.14em] text-white">Back to collections</Link></div></div>;

  const images = product.images?.length ? product.images : ["/manus-storage/editorial-saree_2a91400a.jpg"];
  const orderMessage = `Hi VESatikaa! I'd like to order ${product.name} for ${formatInr(product.price)}. Please confirm size, availability and delivery details.`;
  const customerDescription = product.description.split(/(?<=[.!?])\s+/).filter(Boolean).slice(0, 2).join(" ");

  const specifications = [
    ["Age", product.ageRange],
    ["Size", product.size],
    ["Measurements", "Share measurements"],
    ["Fabric type", product.clothQuality],
    ["Care", "Dry clean"],
  ];

  return (
    <div className="min-h-screen bg-[#fbf7f2]"><StoreHeader whatsappNumber={settings.whatsappNumber} /><main className="container py-8 sm:py-14"><Link href="/#collections" className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.14em] text-[#756a63] transition-colors hover:text-[#6f1d35]"><ArrowLeft className="h-4 w-4" /> Back to collection</Link><div className="mt-8 grid gap-10 lg:grid-cols-[1.1fr_.9fr] lg:gap-20"><div className="grid gap-3 sm:grid-cols-[88px_1fr]"><div className="order-2 flex gap-3 overflow-x-auto sm:order-1 sm:flex-col">{images.map((image, index) => <button key={`${image}-${index}`} onClick={() => setSelectedImage(index)} className={`h-20 w-16 shrink-0 overflow-hidden rounded-xl border-2 sm:h-24 sm:w-20 ${selectedImage === index ? "border-[#6f1d35]" : "border-transparent"}`}><img src={image} alt={`${product.name} view ${index + 1}`} className="h-full w-full object-contain sm:object-cover" /></button>)}</div><motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="image-reveal order-1 h-[240px] overflow-hidden rounded-[1.5rem] bg-[#eaded5] sm:order-2 sm:aspect-[.85] sm:h-auto"><img src={images[selectedImage]} alt={product.name} className="h-full w-full object-contain sm:object-cover" /></motion.div></div><div className="flex flex-col justify-center"><p className="eyebrow">{product.category}</p><h1 className="mt-4 text-5xl leading-[1.03] tracking-[-0.04em] text-[#6f1d35] sm:text-6xl">{product.name}</h1><div className="mt-5 flex flex-wrap items-center gap-3"><p className="text-2xl font-semibold text-[#a17745]">{formatInr(product.price)}</p><span className={`rounded-full px-3 py-1 text-[0.64rem] font-bold uppercase tracking-[0.12em] ${product.availableStock > 0 ? "bg-[#e5f0e7] text-[#2f6b43]" : "bg-[#f1ebe5] text-[#756a63]"}`}>{product.availableStock > 0 ? "Stock available" : "Currently unavailable"}</span></div><div className="gold-rule my-7" /><p className="max-w-lg text-sm leading-7 text-[#756a63] sm:text-base">{customerDescription}</p><div className="mt-7 grid gap-px overflow-hidden rounded-[1.25rem] border border-[#eaded5] bg-[#eaded5] sm:grid-cols-2">{specifications.map(([label, value]) => <div key={label} className="bg-[#fffdf9] px-3 py-3 sm:px-4 sm:py-4"><p className="text-[0.54rem] font-bold uppercase tracking-[0.08em] text-[#a17745] sm:text-[0.62rem] sm:tracking-[0.14em]">{label}</p><p className="mt-1.5 text-xs leading-5 text-[#6f1d35] sm:mt-2 sm:text-sm">{value}</p></div>)}</div><div className="mt-8 rounded-[1.25rem] border border-[#eaded5] bg-[#fffdf9] p-5"><p className="text-xs font-bold uppercase tracking-[0.15em] text-[#6f1d35]">Order directly</p><p className="mt-2 text-sm leading-6 text-[#756a63]">Send your preferred size and delivery details on WhatsApp. We will confirm availability and guide you through the order.</p><a href={whatsappLink(settings.whatsappNumber, orderMessage)} target="_blank" rel="noreferrer" className="luxury-button mt-5 inline-flex w-full items-center justify-center gap-3 rounded-full bg-[#6f1d35] px-5 py-3.5 text-xs font-bold uppercase tracking-[0.14em] text-white hover:bg-[#54202f]"><MessageCircle className="h-4 w-4" /> {product.availableStock > 0 ? "Order on WhatsApp" : "Ask about availability"}</a></div><div className="mt-9 flex items-center justify-between border-t border-[#eaded5] pt-5 text-[0.68rem] font-bold uppercase tracking-[0.12em] text-[#756a63]"><span>{product.featured ? "Featured edit" : "Current edit"}</span><span>{product.newArrival ? "New arrival" : product.availableStock > 0 ? "In stock" : "Availability on request"}</span></div></div></div></main><section className="border-t border-[#eaded5] py-8"><div className="container flex items-center justify-between"><Link href="/#collections" className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.14em] text-[#6f1d35]"><ChevronLeft className="h-4 w-4" /> Explore more</Link><a href={whatsappLink(settings.whatsappNumber, "Hi VESatikaa! I'd like to discuss a custom order.")} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.14em] text-[#6f1d35]">Custom order <ChevronRight className="h-4 w-4" /></a></div></section></div>
  );
}
