CREATE TABLE `galleryItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`imageUrl` text NOT NULL,
	`imageKey` varchar(500),
	`caption` varchar(180),
	`altText` varchar(220) NOT NULL,
	`sortOrder` int NOT NULL DEFAULT 0,
	`published` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `galleryItems_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `products` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(180) NOT NULL,
	`slug` varchar(220) NOT NULL,
	`price` int NOT NULL DEFAULT 0,
	`category` enum('Sarees','Dresses','Custom Orders','New Arrivals') NOT NULL DEFAULT 'Sarees',
	`description` text NOT NULL,
	`images` varchar(12000) NOT NULL,
	`featured` boolean NOT NULL DEFAULT false,
	`newArrival` boolean NOT NULL DEFAULT false,
	`published` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `products_id` PRIMARY KEY(`id`),
	CONSTRAINT `products_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `siteSettings` (
	`id` int NOT NULL,
	`whatsappNumber` varchar(30) NOT NULL,
	`instagramHandle` varchar(120) NOT NULL,
	`founderName` varchar(120) NOT NULL,
	`founderBio` text NOT NULL,
	`founderImageUrl` text,
	`founderImageKey` varchar(500),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `siteSettings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `gallery_sort_idx` ON `galleryItems` (`sortOrder`);--> statement-breakpoint
CREATE INDEX `gallery_published_idx` ON `galleryItems` (`published`);--> statement-breakpoint
CREATE INDEX `products_published_idx` ON `products` (`published`);--> statement-breakpoint
CREATE INDEX `products_category_idx` ON `products` (`category`);--> statement-breakpoint
CREATE INDEX `products_created_idx` ON `products` (`createdAt`);