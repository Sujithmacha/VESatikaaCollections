ALTER TABLE `products` ADD `ageRange` varchar(120) DEFAULT 'Adults / 18+' NOT NULL;--> statement-breakpoint
ALTER TABLE `products` ADD `size` varchar(180) DEFAULT 'Custom fit available' NOT NULL;--> statement-breakpoint
ALTER TABLE `products` ADD `clothQuality` varchar(500) DEFAULT 'Premium occasion fabric' NOT NULL;--> statement-breakpoint
ALTER TABLE `products` ADD `stitchingType` varchar(220) DEFAULT 'Finished to order' NOT NULL;