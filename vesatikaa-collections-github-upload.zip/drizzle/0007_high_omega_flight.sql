ALTER TABLE `products` MODIFY COLUMN `measurements` varchar(800) NOT NULL DEFAULT 'Share measurements';--> statement-breakpoint
ALTER TABLE `products` MODIFY COLUMN `clothQuality` varchar(500) NOT NULL DEFAULT 'Fabric type not added yet';--> statement-breakpoint
ALTER TABLE `products` MODIFY COLUMN `careInstructions` varchar(800) NOT NULL DEFAULT 'Dry clean';--> statement-breakpoint
ALTER TABLE `products` ADD `totalStock` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `products` ADD `availableStock` int DEFAULT 0 NOT NULL;