import {
  boolean,
  index,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const productCategories = ["Kids Wear", "Sarees", "Couple Wear"] as const;
export type ProductCategory = (typeof productCategories)[number];

export const products = mysqlTable(
  "products",
  {
    id: int("id").autoincrement().primaryKey(),
    name: varchar("name", { length: 180 }).notNull(),
    slug: varchar("slug", { length: 220 }).notNull().unique(),
    price: int("price").notNull().default(0),
    category: mysqlEnum("category", productCategories).notNull().default("Sarees"),
    description: text("description").notNull(),
    ageRange: varchar("ageRange", { length: 120 }).notNull().default("Adults / 18+"),
    size: varchar("size", { length: 180 }).notNull().default("Custom fit available"),
    measurements: varchar("measurements", { length: 800 }).notNull().default("Share measurements"),
    clothQuality: varchar("clothQuality", { length: 500 }).notNull().default("Fabric type not added yet"),
    stitchingType: varchar("stitchingType", { length: 220 }).notNull().default("Finished to order"),
    careInstructions: varchar("careInstructions", { length: 800 }).notNull().default("Dry clean"),
    images: varchar("images", { length: 12000 }).notNull(),
    featured: boolean("featured").notNull().default(false),
    newArrival: boolean("newArrival").notNull().default(false),
    published: boolean("published").notNull().default(false),
    stockAvailable: boolean("stockAvailable").notNull().default(true),
    totalStock: int("totalStock").notNull().default(0),
    availableStock: int("availableStock").notNull().default(0),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    publishedIdx: index("products_published_idx").on(table.published),
    categoryIdx: index("products_category_idx").on(table.category),
    createdIdx: index("products_created_idx").on(table.createdAt),
  }),
);

export const siteSettings = mysqlTable("siteSettings", {
  id: int("id").primaryKey(),
  whatsappNumber: varchar("whatsappNumber", { length: 30 }).notNull(),
  instagramHandle: varchar("instagramHandle", { length: 120 }).notNull(),
  founderName: varchar("founderName", { length: 120 }).notNull(),
  founderBio: text("founderBio").notNull(),
  founderImageUrl: text("founderImageUrl"),
  founderImageKey: varchar("founderImageKey", { length: 500 }),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const galleryItems = mysqlTable(
  "galleryItems",
  {
    id: int("id").autoincrement().primaryKey(),
    imageUrl: text("imageUrl").notNull(),
    imageKey: varchar("imageKey", { length: 500 }),
    caption: varchar("caption", { length: 180 }),
    altText: varchar("altText", { length: 220 }).notNull(),
    sortOrder: int("sortOrder").notNull().default(0),
    published: boolean("published").notNull().default(true),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    sortIdx: index("gallery_sort_idx").on(table.sortOrder),
    publishedIdx: index("gallery_published_idx").on(table.published),
  }),
);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Product = typeof products.$inferSelect;
export type InsertProduct = typeof products.$inferInsert;
export type SiteSettings = typeof siteSettings.$inferSelect;
export type GalleryItem = typeof galleryItems.$inferSelect;
