import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

describe("admin email allowlist", () => {
  it("rejects an admin-role account whose email is not the authorized owner address", async () => {
    const ctx: TrpcContext = {
      user: {
        id: 1,
        openId: "other-admin",
        email: "someone-else@example.com",
        name: "Other Admin",
        loginMethod: "manus",
        role: "admin",
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      },
      req: {} as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    };

    const caller = appRouter.createCaller(ctx);
    await expect(caller.products.adminList({})).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
