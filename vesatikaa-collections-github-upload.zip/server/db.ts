import { and, desc, eq, like, or } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, ProductCategory, galleryItems, products, siteSettings, users } from "../drizzle/schema";
import { AUTHORIZED_ADMIN_EMAIL } from "@shared/const";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try { _db = drizzle(process.env.DATABASE_URL); } catch (error) { console.warn("[Database] Failed to connect:", error); _db = null; }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) { values[field] = user[field] ?? null; updateSet[field] = user[field] ?? null; }
  }
  if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
  const isAuthorizedOwner = user.email?.trim().toLowerCase() === AUTHORIZED_ADMIN_EMAIL;
  if (isAuthorizedOwner || user.openId === ENV.ownerOpenId) { values.role = "admin"; updateSet.role = "admin"; }
  else if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
  values.lastSignedIn ??= new Date(); updateSet.lastSignedIn ??= new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

function parseImages(value: string): string[] {
  try { const parsed = JSON.parse(value); return Array.isArray(parsed) ? parsed.filter((item): item is string => typeof item === "string") : []; } catch { return []; }
}
function serializeProduct(row: typeof products.$inferSelect) { return { ...row, images: parseImages(row.images) }; }

export async function listPublishedProducts(category?: string) {
  const db = await getDb();
  if (!db) return [];
  const whereClause = category && category !== "All" ? and(eq(products.published, true), eq(products.category, category as ProductCategory)) : eq(products.published, true);
  const rows = await db.select().from(products).where(whereClause).orderBy(desc(products.featured), desc(products.createdAt));
  return rows.map(serializeProduct);
}

export async function searchAdminProducts(search?: string) {
  const db = await getDb();
  if (!db) return [];
  const whereClause = search?.trim() ? or(like(products.name, `%${search.trim()}%`), like(products.category, `%${search.trim()}%`)) : undefined;
  const rows = await db.select().from(products).where(whereClause).orderBy(desc(products.updatedAt));
  return rows.map(serializeProduct);
}

export async function getProductBySlug(slug: string, includeUnpublished = false) {
  const db = await getDb();
  if (!db) return undefined;
  const whereClause = includeUnpublished ? eq(products.slug, slug) : and(eq(products.slug, slug), eq(products.published, true));
  const rows = await db.select().from(products).where(whereClause).limit(1);
  return rows[0] ? serializeProduct(rows[0]) : undefined;
}

export async function getProductById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(products).where(eq(products.id, id)).limit(1);
  return rows[0] ? serializeProduct(rows[0]) : undefined;
}

export async function createProduct(input: { name: string; slug: string; price: number; category: ProductCategory; description: string; ageRange: string; size: string; measurements: string; clothQuality: string; stitchingType: string; careInstructions: string; images: string[]; featured: boolean; newArrival: boolean; published: boolean; stockAvailable: boolean; totalStock: number; availableStock: number }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(products).values({ ...input, stockAvailable: input.availableStock > 0, images: JSON.stringify(input.images) });
  return getProductById(Number(result[0].insertId));
}

export async function updateProduct(id: number, input: Partial<Omit<Parameters<typeof createProduct>[0], "slug">>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const update: Record<string, unknown> = { ...input };
  if (input.images) update.images = JSON.stringify(input.images);
  if (input.availableStock !== undefined) update.stockAvailable = input.availableStock > 0;
  await db.update(products).set(update).where(eq(products.id, id));
  return getProductById(id);
}

export async function deleteProduct(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(products).where(eq(products.id, id));
  return { success: true } as const;
}

const defaultSettings = { id: 1, whatsappNumber: "+91 8328536597", instagramHandle: "@vesatikaa_collections_2024", founderName: "Samatha Mallekedi", founderBio: "VESatikaa Collections is a space for women who want their ethnic wear to feel personal. Samatha works with each customer to shape the silhouette, colour story and finishing details around the moment they are dressing for.", founderImageUrl: null as string | null, founderImageKey: null as string | null };
type SettingsUpdate = Partial<Pick<typeof defaultSettings, "whatsappNumber" | "instagramHandle" | "founderName" | "founderBio" | "founderImageUrl" | "founderImageKey">>;

export async function getSiteSettings() {
  const db = await getDb();
  if (!db) return defaultSettings;
  const rows = await db.select().from(siteSettings).where(eq(siteSettings.id, 1)).limit(1);
  return rows[0] ?? defaultSettings;
}

export async function updateSiteSettings(input: SettingsUpdate) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const safeInput = { ...input, founderImageUrl: input.founderImageUrl || null, founderImageKey: input.founderImageKey || null };
  await db.insert(siteSettings).values({ ...defaultSettings, ...safeInput, id: 1 }).onDuplicateKeyUpdate({ set: { ...safeInput, updatedAt: new Date() } });
  return getSiteSettings();
}

export async function listGallery(publishedOnly = true) {
  const db = await getDb();
  if (!db) return [];
  const whereClause = publishedOnly ? eq(galleryItems.published, true) : undefined;
  return db.select().from(galleryItems).where(whereClause).orderBy(galleryItems.sortOrder, desc(galleryItems.createdAt));
}

export async function createGalleryItem(input: { imageUrl: string; imageKey?: string; caption?: string; altText: string; sortOrder: number; published: boolean }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(galleryItems).values(input);
  const rows = await db.select().from(galleryItems).where(eq(galleryItems.id, Number(result[0].insertId))).limit(1);
  return rows[0];
}

export async function deleteGalleryItem(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(galleryItems).where(eq(galleryItems.id, id));
  return { success: true } as const;
}
