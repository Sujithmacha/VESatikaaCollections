import { describe, expect, it } from "vitest";
import { productCategories } from "../drizzle/schema";

describe("product categories", () => {
  it("includes the website catalogue options", () => {
    expect(productCategories).toEqual(["Kids Wear", "Sarees", "Couple Wear"]);
  });
});
