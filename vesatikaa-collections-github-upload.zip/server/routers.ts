import { AUTHORIZED_ADMIN_EMAIL, COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { storagePut } from "./storage";
import {
  createGalleryItem,
  createProduct,
  deleteGalleryItem,
  deleteProduct,
  getProductById,
  getProductBySlug,
  getSiteSettings,
  listGallery,
  listPublishedProducts,
  searchAdminProducts,
  updateProduct,
  updateSiteSettings,
} from "./db";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { productCategories } from "../drizzle/schema";

const productInput = z.object({
  name: z.string().trim().min(2).max(180),
  price: z.number().int().min(0).max(100000000),
  category: z.enum(productCategories),
  description: z.string().trim().min(10).max(4000),
  ageRange: z.string().trim().min(2).max(120),
  size: z.string().trim().min(2).max(180),
  measurements: z.string().trim().min(2).max(800).default("Share measurements"),
  clothQuality: z.string().trim().min(2).max(500).default("Fabric type not added yet"),
  stitchingType: z.string().trim().min(2).max(220).default("Finished to order"),
  careInstructions: z.string().trim().min(2).max(800).default("Dry clean"),
  images: z.array(z.string().trim().min(1).max(600)).max(8),
  featured: z.boolean().default(false),
  newArrival: z.boolean().default(false),
  published: z.boolean().default(false),
  stockAvailable: z.boolean().default(true),
  totalStock: z.number().int().min(0).default(0),
  availableStock: z.number().int().min(0).default(0),
});

const uploadInput = z.object({
  fileName: z.string().trim().min(1).max(180),
  contentType: z.enum(["image/jpeg", "image/png", "image/webp"]),
  dataBase64: z.string().min(1).max(7400000),
});

const adminGuard = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin" || ctx.user.email?.trim().toLowerCase() !== AUTHORIZED_ADMIN_EMAIL) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Admin access is required." });
  }
  return next({ ctx });
});

function slugify(value: string) {
  return value.toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "").slice(0, 120);
}

function validateImageData(input: z.infer<typeof uploadInput>) {
  const bytes = Buffer.from(input.dataBase64, "base64");
  if (bytes.byteLength > 5 * 1024 * 1024) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Images must be 5MB or smaller." });
  }
  if (bytes.byteLength < 100) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "The image file appears to be empty or invalid." });
  }
  return bytes;
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  products: router({
    list: publicProcedure
      .input(z.object({ category: z.string().optional() }).optional())
      .query(({ input }) => listPublishedProducts(input?.category)),
    bySlug: publicProcedure.input(z.object({ slug: z.string().min(1) })).query(({ input }) => getProductBySlug(input.slug)),
    adminList: adminGuard.input(z.object({ search: z.string().optional() }).optional()).query(({ input }) => searchAdminProducts(input?.search)),
    create: adminGuard.input(productInput).mutation(({ input }) => createProduct({ ...input, slug: `${slugify(input.name)}-${Date.now().toString(36)}` })),
    update: adminGuard.input(productInput.extend({ id: z.number().int().positive() })).mutation(({ input }) => {
      const { id, ...values } = input;
      return updateProduct(id, values);
    }),
    delete: adminGuard.input(z.object({ id: z.number().int().positive() })).mutation(({ input }) => deleteProduct(input.id)),
    uploadImage: adminGuard.input(uploadInput).mutation(async ({ input, ctx }) => {
      const bytes = validateImageData(input);
      const safeName = input.fileName.toLowerCase().replace(/[^a-z0-9.]+/g, "-");
      return storagePut(`vesatikaa/${ctx.user.id}/${Date.now()}-${safeName}`, bytes, input.contentType);
    }),
  }),
  settings: router({
    get: publicProcedure.query(() => getSiteSettings()),
    update: adminGuard.input(z.object({
      whatsappNumber: z.string().trim().min(8).max(30),
      instagramHandle: z.string().trim().min(1).max(120),
      founderName: z.string().trim().min(2).max(120),
      founderBio: z.string().trim().min(20).max(3000),
      founderImageUrl: z.string().trim().max(600).optional().or(z.literal("")),
      founderImageKey: z.string().trim().max(500).optional().or(z.literal("")),
    })).mutation(({ input }) => updateSiteSettings(input)),
  }),
  gallery: router({
    list: publicProcedure.query(() => listGallery(true)),
    adminList: adminGuard.query(() => listGallery(false)),
    create: adminGuard.input(z.object({
      imageUrl: z.string().trim().min(1).max(600),
      imageKey: z.string().trim().max(500).optional(),
      caption: z.string().trim().max(180).optional(),
      altText: z.string().trim().min(3).max(220),
      sortOrder: z.number().int().min(0).max(999),
      published: z.boolean().default(true),
    })).mutation(({ input }) => createGalleryItem(input)),
    delete: adminGuard.input(z.object({ id: z.number().int().positive() })).mutation(({ input }) => deleteGalleryItem(input.id)),
  }),
});

export type AppRouter = typeof appRouter;
