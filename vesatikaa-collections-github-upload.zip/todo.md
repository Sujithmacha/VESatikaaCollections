# VESatikaa Collections task tracker

- [x] Keep the admin panel inside the website at `/admin` with protected sign-in.
- [x] Support product editing and new product photo uploads from the admin panel.
- [x] Support gallery photo uploads and deletion from the admin panel.
- [x] Add product fields for price, size/fit, cloth quality, and stitching type.
- [x] Add product options for Kid Wear, Adult Wear, Sarees, Dresses, Stitching, Custom Orders, and New Arrivals.
- [x] Add public storefront filters for Kid Wear, Adult Wear, Sarees, Dresses, Stitching, and New Arrivals.
- [x] Add exact garment measurements and care instructions per product when content is available.
